﻿namespace Product.BLL.Managers.FuncArea
{
    using Product.Domain.FuncArea;
    using Product.DAL.Repositories.FuncArea;

    /// <summary>
    /// Класа со бизнис логика за Parent
    /// </summary>
    public class ParentManager : ManagerBase
    {
        #region Constructors

        public ParentManager()
            : base()
        {

        }

        #endregion

        #region Get

        /// <summary>
        /// Метод кој ги враќа сите Parent објекти
        /// </summary>
        /// <returns></returns>
        public ParentCollection GetAll()
        {
            ParentRepository repository = new ParentRepository();
            ParentCollection domainObjects = repository.GetAll();

            return domainObjects;
        }

        /// <summary>
        /// Метод кој го враќа Parent-от со даденото id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public Parent Get(int id)
        {
            ParentRepository repository = new ParentRepository();
            Parent domainObject = repository.Get(id);

            return domainObject;
        }

        /// <summary>
        /// Метод кој го враќа Parent-от со даденото id, заедно со сите негови Child објекти
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public Parent GetWithChildren(int id)
        {
            ParentRepository parentRepository = new ParentRepository();
            Parent parentObject = parentRepository.Get(id);

            ChildRepository childRepository = new ChildRepository();
            ChildCollection childObjects = childRepository.GetByParentId(id);

            foreach(Child child in childObjects)
            {
                parentObject.Children.Add(child);
            }

            return parentObject;
        }

        #endregion

        #region Insert

        /// <summary>
        /// Метод кој создава нов Parent во базата на податоци и го враќа новиот објект
        /// </summary>
        /// <param name="domainObject"></param>
        /// <returns></returns>
        public Parent Create(Parent domainObject)
        {
            ParentRepository repository = new ParentRepository();
            Parent result = repository.Insert(domainObject);

            return result;
        }

        #endregion

        #region Update

        /// <summary>
        /// Метод кој ги менува податоците за дадениот Parent објект во базата на податоци
        /// и го враќа изменетиот објект
        /// </summary>
        /// <param name="domainObject"></param>
        /// <returns></returns>
        public Parent Update(Parent domainObject)
        {
            ParentRepository repository = new ParentRepository();
            Parent result = repository.Update(domainObject);

            return result;
        }

        #endregion

    }
}
