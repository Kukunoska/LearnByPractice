﻿namespace Product.BLL.Managers.FuncArea
{
    using Product.Domain.FuncArea;
    using Product.DAL.Repositories.FuncArea;

    /// <summary>
    /// Класа со бизнис логика за Child
    /// </summary>
    public class ChildManager : ManagerBase
    {
        #region Constructors

        public ChildManager()
            : base()
        {

        }

        #endregion

        #region Get

        /// <summary>
        /// Метод кој го враќа Child објектот со наведеното id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public Child Get(int id)
        {
            ChildRepository repository = new ChildRepository();
            Child domainObject = repository.Get(id);

            return domainObject;
        }

        /// <summary>
        /// Метод кој ги враќа сите Child објекти
        /// </summary>
        /// <returns></returns>
        public ChildCollection GetAll()
        {
            ChildRepository repository = new ChildRepository();
            ChildCollection domainObjects = repository.GetAll();

            return domainObjects;
        }

        #endregion

        #region Insert

        /// <summary>
        /// Метод кој создава нов Child во базата на податоци и го враќа новиот објект
        /// </summary>
        /// <param name="domainObject"></param>
        /// <returns></returns>
        public Child Create(Child domainObject)
        {
            ChildRepository repository = new ChildRepository();
            Child result = repository.Insert(domainObject);

            return result;
        }

        #endregion

    }
}
