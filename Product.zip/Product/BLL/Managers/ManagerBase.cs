﻿namespace Product.BLL.Managers
{
    /// <summary>
    /// Основна класа за сите останати класи кои ја имплементираат бизнис логиката
    /// </summary>
    public abstract class ManagerBase
    {
        #region Constructors

        protected ManagerBase()
        {

        }

        #endregion
    }
}
