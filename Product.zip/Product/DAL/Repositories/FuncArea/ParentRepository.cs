﻿namespace Product.DAL.Repositories.FuncArea
{
    using System;
    using System.Collections.Generic;
    using System.Linq;

    using domain = Product.Domain.FuncArea;
    using models = Product.DAL.Models;

    /// <summary>
    /// Класа за пристап до табелата Parent
    /// </summary>
    public class ParentRepository : RepositoryBase
    {
        #region Constructors

        public ParentRepository()
            : base()
        {

        }

        #endregion

        #region Helpers

        /// <summary>
        /// Претворање на char(1) вредностите во вредности од енумерацијата
        /// </summary>
        /// <param name="modelVid"></param>
        /// <returns></returns>
        protected domain.Vid ToDomain(char modelVid)
        {
            switch (modelVid)
            {
                case 'A':
                    return domain.Vid.A;

                case 'B':
                    return domain.Vid.B;

                case 'C':
                    return domain.Vid.C;

                default:
                    throw new ArgumentOutOfRangeException("modelVid", "Неочекувана вредноста на VidParent е прочитана од базата на податоци.");
            }
        }


        /// <summary>
        /// Помошен метод за претворање на model објект (кој се користи за пристап до податоците)
        /// во domain објект (кој се користи во погорните нивоа на кодот)
        /// </summary>
        /// <param name="modelObject"></param>
        /// <returns></returns>
        protected domain.Parent ToDomain(models.Parent modelObject)
        {
            domain.Parent domainObject = new domain.Parent();
            domainObject.Id = modelObject.IdParent;
            domainObject.Ime = modelObject.ImeParent;
            domainObject.Vid = ToDomain(modelObject.VidParent);

            return domainObject;
        }

        /// <summary>
        /// Помошен метод за претворање на листа од model објекти во соодветна листа од domain објекти
        /// (се користи постоечкиот помошен метод за претворање на поединечен објект)
        /// </summary>
        /// <param name="modelObjects"></param>
        /// <returns></returns>
        protected domain.ParentCollection ToDomainObjects(IEnumerable<models.Parent> modelObjects)
        {
            domain.ParentCollection domainObjects = new domain.ParentCollection();

            foreach(models.Parent modelObject in modelObjects)
            {
                // Секој одделен model објект се претвора во соодветниот domain објект ...
                domain.Parent domainObject = ToDomain(modelObject);
                // ... и се додава на колекцијата ...
                domainObjects.Add(domainObject);
            }

            // ... која на крајот се враќа како резултат
            return domainObjects;
        }

        /// <summary>
        /// Претворање од enum во char(1)
        /// </summary>
        /// <param name="domainVid"></param>
        /// <returns></returns>
        protected char ToModel(domain.Vid domainVid)
        {

            switch (domainVid)
            {
                case domain.Vid.A:
                    return 'A';

                case domain.Vid.B:
                    return 'B';

                case domain.Vid.C:
                    return 'C';

                default:
                    throw new ArgumentOutOfRangeException("domainVid", "Обид за запишување на неочекувана вредноста на Vid во базата на податоци.");
            }
        }


        #endregion

        #region Get

        /// <summary>
        /// Метод за вчитување на еден parent врз основа на неговото id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public domain.Parent Get(int id)
        {
            using(models.ProductDataContext context = CreateContext())
            {
                IQueryable<models.Parent> query = context.Parents.Where(p => p.IdParent == id);
                // Употребата на .Single() значи дека query-то мора да врати ТОЧНО еден елемент
                // (во било кој друг случај ќе се јави грешка)
                domain.Parent domainObject = ToDomain(query.Single());

                return domainObject;
            }
        }

        /// <summary>
        /// Метод кој ги враќа сите Parent објекти од базата на податоци
        /// </summary>
        /// <returns></returns>
        public domain.ParentCollection GetAll()
        {
            using(models.ProductDataContext context = CreateContext())
            {
                IQueryable<models.Parent> query = context.Parents; // Нема никаков филтер
                domain.ParentCollection domainObjects = ToDomainObjects(query.ToList());

                return domainObjects;
            }
        }

        #endregion

        #region Insert

        /// <summary>
        /// Метод кој додава нов запис во табелата Parent и го враќа новиот запис
        /// (заедно со генерираното ИД)
        /// </summary>
        /// <param name="domainObject"></param>
        /// <returns></returns>
        public domain.Parent Insert(domain.Parent domainObject)
        {
            using(models.ProductDataContext context = CreateContext())
            {
                models.Parent modelObject = new models.Parent();
                // modelObject.IdParent не се поставува, туку се генерира
                modelObject.ImeParent = domainObject.Ime;
                modelObject.VidParent = ToModel(domainObject.Vid);

                // model објектот се регистрира за INSERT при следното запишување во базата ...
                context.Parents.InsertOnSubmit(modelObject);

                // ... кое се случува веднаш после регистрирањето
                context.SubmitChanges();
                // После ова, генерираното ИД е сместено во model објектот

                // На крајот, запишаниот model објект се враќа како резултат, заедно со генерираното ИД
                domain.Parent result = ToDomain(modelObject);

                return result;
            }
        }

        #endregion

        #region Update

        /// <summary>
        /// Метод кој ги менува податоците за дадениот Parent објект во табелата Parent
        /// и го враќа изменетиот објект
        /// </summary>
        /// <param name="domainObject"></param>
        /// <returns></returns>
        public domain.Parent Update(domain.Parent domainObject)
        {
            using(models.ProductDataContext context = CreateContext())
            {
                // Слично како кај Get(id) методот
                IQueryable<models.Parent> query = context.Parents.Where(p => p.IdParent == domainObject.Id);
                models.Parent modelObject = query.Single();

                // Измена на вредностите
                modelObject.ImeParent = domainObject.Ime;
                modelObject.VidParent = ToModel(domainObject.Vid);

                // Запишување на измените
                context.SubmitChanges();

                // Читање на изменетиот објект
                domain.Parent result = ToDomain(modelObject);

                return result;
            }
        }

        #endregion
    }
}
