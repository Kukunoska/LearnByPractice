﻿namespace Product.DAL.Repositories.FuncArea
{
    using System.Collections.Generic;
    using System.Linq;

    using domain = Product.Domain.FuncArea;
    using models = Product.DAL.Models;

    /// <summary>
    /// Класа за пристап до табелата Child
    /// </summary>
    public class ChildRepository : RepositoryBase
    {
        #region Constructors

        public ChildRepository()
            : base()
        {

        }

        #endregion

        #region Helpers

        /// <summary>
        /// Помошен метод за претворање на model објект (кој се користи за пристап до податоците)
        /// во domain објект (кој се користи во погорните нивоа на кодот)
        /// </summary>
        /// <param name="modelObject"></param>
        /// <returns></returns>
        protected domain.Child ToDomain(models.Child modelObject)
        {
            domain.Child domainObject = new domain.Child();
            domainObject.Id = modelObject.IdChild;
            domainObject.Ime = modelObject.ImeChild;
            domainObject.IdParent = modelObject.ParentId;

            return domainObject;
        }

        /// <summary>
        /// Помошен метод за претворање на листа од model објекти во соодветна листа од domain објекти
        /// (се користи постоечкиот помошен метод за претворање на поединечен објект)
        /// </summary>
        /// <param name="modelObjects"></param>
        /// <returns></returns>
        protected domain.ChildCollection ToDomainObjects(IEnumerable<models.Child> modelObjects)
        {
            domain.ChildCollection domainObjects = new domain.ChildCollection();

            foreach (models.Child modelObject in modelObjects)
            {
                // Секој одделен model објект се претвора во соодветниот domain објект ...
                domain.Child domainObject = ToDomain(modelObject);
                // ... и се додава на колекцијата ...
                domainObjects.Add(domainObject);
            }

            // ... која на крајот се враќа како резултат
            return domainObjects;
        }

        #endregion

        #region Get

        /// <summary>
        /// Метод за вчитување на СИТЕ деца од табелата
        /// </summary>
        /// <returns></returns>
        public domain.ChildCollection GetAll()
        {
            using(models.ProductDataContext context = CreateContext())
            {
                IQueryable<models.Child> query = context.Childs; // Нема филтер
                domain.ChildCollection domainObjects = ToDomainObjects(query.ToList());

                return domainObjects;
            }
        }

        /// <summary>
        /// Метод за вчитување на еден child врз основа на неговото id
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public domain.Child Get(int id)
        {
            using (models.ProductDataContext context = CreateContext())
            {
                IQueryable<models.Child> query = context.Childs.Where(c => c.IdChild == id);
                // Употребата на .Single() значи дека query-то мора да врати ТОЧНО еден елемент
                // (во било кој друг случај ќе се јави грешка)
                domain.Child domainObject = ToDomain(query.Single());

                return domainObject;
            }
        }

        /// <summary>
        /// Метод за вчитување на сите child записи за даден parent id
        /// </summary>
        /// <param name="parentId"></param>
        /// <returns></returns>
        public domain.ChildCollection GetByParentId(int parentId)
        {
            using (models.ProductDataContext context = CreateContext())
            {
                IQueryable<models.Child> query = context.Childs.Where(c => c.ParentId == parentId);
                // Во моментот кога се извршува .ToList(), претходното query се претвора во SQL наредби
                // кои се испраќаат до базата
                domain.ChildCollection domainObjects = ToDomainObjects(query.ToList());

                return domainObjects;
            }
        }

        #endregion

        #region Insert

        /// <summary>
        /// Метод кој додава нов запис во табелата Child и го враќа новиот запис
        /// (заедно со генерираното ИД)
        /// </summary>
        /// <param name="domainObject"></param>
        /// <returns></returns>
        public domain.Child Insert(domain.Child domainObject)
        {
            using(models.ProductDataContext context = CreateContext())
            {
                models.Child modelObject = new models.Child();
                // modelObject.IdChild не се поставува, туку се генерира
                modelObject.ImeChild = domainObject.Ime;
                modelObject.ParentId = domainObject.IdParent;

                // model објектот се регистрира за INSERT при следното запишување во базата ...
                context.Childs.InsertOnSubmit(modelObject);

                // ... кое се случува веднаш после регистрирањето
                context.SubmitChanges();
                // После ова, генерираното ИД е сместено во model објектот

                // На крајот, запишаниот model објект се враќа како резултат, заедно со генерираното ИД
                domain.Child result = ToDomain(modelObject);

                return result;

            }
        }

        #endregion
    }
}
