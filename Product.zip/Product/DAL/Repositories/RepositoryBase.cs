﻿namespace Product.DAL.Repositories
{
    using Product.DAL.Models;

    /// <summary>
    /// Основна класа за repository
    /// </summary>
    public abstract class RepositoryBase
    {
        #region Constructors

        protected RepositoryBase()
        {

        }

        #endregion

        #region Helpers

        /// <summary>
        /// Помошен метод кој креира и враќа data context
        /// (идејата е да се централизира креирањето и конфигурирањето на вакви објекти)
        /// </summary>
        /// <returns></returns>
        protected ProductDataContext CreateContext()
        {
            ProductDataContext context = new ProductDataContext();
            context.DeferredLoadingEnabled = false; // Се исклучува автоматското вчитување на поврзани објекти

            return context;
        }

        #endregion
    }
}
