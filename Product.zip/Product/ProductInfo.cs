﻿using System.Reflection;

[assembly: AssemblyCompany("Факултет за информатички и комуникациски технологии - Битола")]
[assembly: AssemblyProduct("Product")]
[assembly: AssemblyCopyright("Copyright © ФИКТ, 2016")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
