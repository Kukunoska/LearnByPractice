﻿namespace Product.UI.Web.UserType
{
    using System;
    using System.Web.UI.WebControls;

    using Product.Domain.FuncArea;
    using Product.BLL.Managers.FuncArea;

    public partial class Children : System.Web.UI.Page
    {
        /// <summary>
        /// Основно URL до страната
        /// </summary>
        public const string PageUrlBase = "~/UserType/Children.aspx";

        /// <summary>
        /// Метод кој го пресметува и враќа URLто кое треба да се употреби за
        /// оваа страна да се повика со филтер по родител ИД
        /// </summary>
        /// <param name="parentId"></param>
        /// <returns></returns>
        public static string PageUrlWithParentId(int parentId)
        {
            return string.Concat(PageUrlBase, "?parentId=", parentId.ToString());
        }

        private int ParentId
        {
            get
            {
                int result = 0;
                string parentIdFromRequest = Request["parentId"];
                if (! string.IsNullOrEmpty(parentIdFromRequest))
                {
                    if (! int.TryParse(parentIdFromRequest, out result))
                    {
                        result = 0;
                    }
                }

                return result;
            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (! IsPostBack)
            {
                int parentId = ParentId;

                ChildManager childManager = new ChildManager();
                ChildCollection deca;

                if (parentId == 0)
                {
                    // Земи ги сите деца
                    deca = childManager.GetAll();
                }
                else
                {
                    // Прво вчитај го родителот и прикажи го ...
                    ParentManager parentManager = new ParentManager();
                    Parent roditel = parentManager.GetWithChildren(parentId);
                    ZaRoditelLiteral.Text = string.Format("за родител '{0}'", roditel.Ime);

                    // ... а на крајот употреби ја колекцијата со децата за приказ во repeater-от
                    deca = roditel.Children;
                }

                ChildrenRepeater.DataSource = deca;
                ChildrenRepeater.DataBind();
            }
        }

        protected void ChildrenRepeater_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            if ((e.Item.ItemType == ListItemType.Item) || (e.Item.ItemType == ListItemType.AlternatingItem))
            {
                // Од event argument-от се добива оригиналниот објект кој одговара на item-от
                Child child = e.Item.DataItem as Child;

                // Прикажување на вредностите во лабелите
                Label idLabel = e.Item.FindControl("IDLabel") as Label;
                idLabel.Text = child.Id.ToString();

                Label imeLabel = e.Item.FindControl("ImeLabel") as Label;
                imeLabel.Text = child.Ime;

                Label roditelIdLabel = e.Item.FindControl("RoditelIdLabel") as Label;
                roditelIdLabel.Text = child.IdParent.ToString();
            }
        }
    }
}