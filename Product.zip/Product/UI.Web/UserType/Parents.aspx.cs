﻿namespace Product.UI.Web.UserType
{
    using System;
    using System.Web.UI.WebControls;

    using Product.Domain.FuncArea;
    using Product.BLL.Managers.FuncArea;

    public partial class Parents : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (! IsPostBack)
            {
                ParentManager manager = new ParentManager();
                ParentCollection roditeli = manager.GetAll();

                ParentsRepeater.DataSource = roditeli;
                ParentsRepeater.DataBind();
            }
        }

        protected void ParentsRepeater_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            if ((e.Item.ItemType == ListItemType.Item) || (e.Item.ItemType == ListItemType.AlternatingItem))
            {
                // Од event argument-от се добива оригиналниот објект кој одговара на item-от
                Parent parent = e.Item.DataItem as Parent;

                // Прикажување на вредностите во лабелите
                Label idLabel = e.Item.FindControl("IDLabel") as Label;
                idLabel.Text = parent.Id.ToString();

                HyperLink imeHyperLink = e.Item.FindControl("ImeHyperLink") as HyperLink;
                imeHyperLink.Text = parent.Ime;
                imeHyperLink.NavigateUrl = Children.PageUrlWithParentId(parent.Id);

                Label vidLabel = e.Item.FindControl("VidLabel") as Label;
                vidLabel.Text = parent.Vid.ToString();
            }
        }
    }
}