﻿namespace Product.Domain.FuncArea
{
    public enum Vid
    {
        None,

        A,

        B,

        C
    }
}
