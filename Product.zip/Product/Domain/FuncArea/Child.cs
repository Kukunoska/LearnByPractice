﻿namespace Product.Domain.FuncArea
{
    public class Child
    {
        #region Properties

        public int Id { get; set; }

        public string Ime { get; set; }

        public int IdParent { get; set; }

        #endregion

        #region Constructors

        public Child()
        {

        }

        #endregion
    }
}
