﻿namespace Product.Domain.FuncArea
{
    using System.Collections.Generic;
    using System.Collections.ObjectModel;

    public class ParentCollection : Collection<Parent>
    {
        #region Constructors

        public ParentCollection()
            : base()
        {
        }

        public ParentCollection(IList<Parent> list)
            : base(list)
        {

        }

        #endregion
    }
}
