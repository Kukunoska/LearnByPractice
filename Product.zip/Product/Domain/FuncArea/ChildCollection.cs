﻿namespace Product.Domain.FuncArea
{
    using System.Collections.Generic;
    using System.Collections.ObjectModel;

    public class ChildCollection : Collection<Child>
    {
        #region Constructors

        public ChildCollection()
            : base()
        {

        }

        public ChildCollection(IList<Child> list)
            : base(list)
        {

        }

        #endregion
    }
}
