﻿namespace Product.Domain.FuncArea
{
    public class Parent
    {
        #region Properties

        public int Id { get; set; }

        public string Ime { get; set; }

        public Vid Vid { get; set; }

        private ChildCollection _children; // Приватна колекција

        public ChildCollection Children
        {
            get { return _children;  } // Read-only
        }

        #endregion

        #region Constructors

        public Parent()
        {
            Vid = Vid.None;
            _children = new ChildCollection(); // Иницијализирање на приватната колекција
        }

        #endregion
    }
}
