﻿namespace Product.Tests.Domain.FuncArea
{
    using NUnit.Framework;

    using Product.Domain.FuncArea;

    /// <summary>
    /// Тестови за класата Parent
    /// </summary>
    [TestFixture]
    public class ParentTests
    {
        [Test]
        public void ConstructorTest()
        {
            // Креирај нов Parent објект ...
            Parent p = new Parent();
            // ... и провери дали неговите својства ги имаат очекуваните вредности
            Assert.AreEqual(0, p.Id);
            Assert.IsNull(p.Ime);
            Assert.AreEqual(Vid.None, p.Vid);
            Assert.IsNotNull(p.Children);
            Assert.AreEqual(0, p.Children.Count);
        }
    }
}
