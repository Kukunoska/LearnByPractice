﻿namespace Product.Tests.Domain.FuncArea
{
    using NUnit.Framework;

    using Product.Domain.FuncArea;

    /// <summary>
    /// Тестови за класата Child
    /// </summary>
    [TestFixture]
    public class ChildTests
    {
        [Test]
        public void ConstructorTest()
        {
            // Креирај нов Child објект ...
            Child c = new Child();
            // ... и провери дали неговите својства ги имаат очекуваните вредности
            Assert.AreEqual(0, c.Id);
            Assert.IsNull(c.Ime);
            Assert.AreEqual(0, c.IdParent);
        }
    }
}
