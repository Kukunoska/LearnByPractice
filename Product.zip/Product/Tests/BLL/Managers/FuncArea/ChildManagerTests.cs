﻿namespace Product.Tests.BLL.Managers.FuncArea
{
    using NUnit.Framework;

    using Product.Domain.FuncArea;
    using Product.BLL.Managers.FuncArea;

    /// <summary>
    /// Тестови за бизнис логиката за Child
    /// </summary>
    [TestFixture]
    public class ChildManagerTests
    {
        /// <summary>
        /// Тест за методот Get
        /// </summary>
        [Test]
        public void GetByIdTest()
        {
            ChildManager manager = new ChildManager();
            Child child = manager.Get(1);
            // Проверка дали податоците се совпаѓаат со оние од Database\InitialData\Child.sql
            Assert.AreEqual(1, child.Id);
            Assert.AreEqual("Дете 1.1", child.Ime);
            Assert.AreEqual(1, child.IdParent);
        }
    }
}
