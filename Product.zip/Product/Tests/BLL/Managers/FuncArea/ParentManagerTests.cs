﻿namespace Product.Tests.BLL.Managers.FuncArea
{
    using System;
    using System.Linq;

    using NUnit.Framework;

    using Product.Domain.FuncArea;
    using Product.BLL.Managers.FuncArea;

    /// <summary>
    /// Тестови за бизнис логиката за Parent
    /// </summary>
    [TestFixture]
    public class ParentManagerTests
    {
        /// <summary>
        /// Тест за методот Get
        /// </summary>
        [Test]
        public void GetByIdTest()
        {
            ParentManager manager = new ParentManager();
            Parent parent = manager.Get(2);
            // Проверка дали податоците се совпаѓаат со оние од Database\InitialData\Parent.sql
            Assert.AreEqual(2, parent.Id);
            Assert.AreEqual(0, parent.Children.Count); /// Испитување дека НЕ се вчитани и децата
        }

        /// <summary>
        /// Тест за методот GetWithChildren
        /// </summary>
        [Test]
        public void GetWithChildrenTest()
        {
            ParentManager manager = new ParentManager();
            Parent parent = manager.GetWithChildren(2);
            // Проверка дали податоците се совпаѓаат со оние од Database\InitialData\Parent.sql
            Assert.AreEqual(2, parent.Id);

            Assert.AreEqual(3, parent.Children.Count); /// Испитување дека СЕ вчитани и децата
            // Испитување дали за сите објекти во parent.Children, IdParent е 2
            Assert.IsTrue(parent.Children.All(dete => dete.IdParent == 2));
            foreach (Child child in parent.Children)
            {
                Console.WriteLine("ИД: {0}, Име: {1}, Родител ИД: {2}", child.Id, child.Ime, child.IdParent);
            }
        }

        /// <summary>
        /// Тест за методот GetAll
        /// </summary>
        [Test]
        public void GetAllTest()
        {
            ParentManager manager = new ParentManager();
            ParentCollection siteParenti = manager.GetAll();
            Assert.IsNotNull(siteParenti);

            Assert.IsTrue(siteParenti.Count >= 3); // Бидејќи во Database\InitialData\Parent.sql додаваме 3 записи

            foreach (Parent edenParent in siteParenti)
            {
                Console.WriteLine("ИД: {0}, Име: {1}, Вид: {2}", edenParent.Id, edenParent.Ime, edenParent.Vid);
            }
        }

        /// <summary>
        /// Помошен метод за генерирање на псеудо-случајна вредност за Vid
        /// </summary>
        /// <returns></returns>
        protected Vid SluchaenVid()
        {
            // За да биди поинтересно, се користат псеудо-случајни броеви
            Random random = new Random(DateTime.Now.Millisecond);

            // 4-ката се исклучува од опсегот, се генерираат броеви од 1 до 3
            int randomInt = random.Next(1, 4);
            switch (randomInt)
            {
                case 1:
                    return Vid.A;

                case 2:
                    return Vid.B;

                case 3:
                    return Vid.C;

                default:
                    throw new InvalidOperationException("Добиена е случајна вредност надвор од дадените граници.");
            }
        }

        /// <summary>
        /// Тест за методот Create
        /// </summary>
        [Test]
        public void CreateTest()
        {
            Parent novRoditel = new Parent();
            novRoditel.Ime = string.Format("Родител {0}", Guid.NewGuid().ToString());
            novRoditel.Vid = SluchaenVid();

            ParentManager manager = new ParentManager();
            Parent dodadenRoditel = manager.Create(novRoditel);

            // Испитување на резултатот
            Assert.IsNotNull(dodadenRoditel);
            // Проверка дали е вратен нов генериран ИД
            Assert.AreNotEqual(0, dodadenRoditel.Id);
            // Проверка дали е запишано она шо требало
            Assert.AreEqual(novRoditel.Ime, dodadenRoditel.Ime);
            Assert.AreEqual(novRoditel.Vid, dodadenRoditel.Vid);

            Console.WriteLine("Додаден е нов родител: ИД: {0}, Име: {1}, Вид: {2}", dodadenRoditel.Id, dodadenRoditel.Ime, dodadenRoditel.Vid);
        }

        /// <summary>
        /// Тест за методот Insert
        /// </summary>
        [Test]
        public void UpdateTest()
        {
            ParentManager manager = new ParentManager();

            // Прво определи за кој родител ќе се менуваат податоците
            ParentCollection siteRoditeli = manager.GetAll();

            Random random = new Random(DateTime.Now.Millisecond);
            int roditelId = random.Next(0, siteRoditeli.Count);
            Parent izbranRoditel = siteRoditeli[roditelId];

            Console.WriteLine("Се менуваат податоците за родител ИД: {0}, Име: {1}, Вид: {2}", izbranRoditel.Id, izbranRoditel.Ime, izbranRoditel.Vid);

            izbranRoditel.Ime = string.Format("Изменет родител {0}", Guid.NewGuid().ToString());
            izbranRoditel.Vid = SluchaenVid();

            Parent izmenetRoditel = manager.Update(izbranRoditel);

            // Испитување на резултатот
            Assert.IsNotNull(izmenetRoditel);
            // Проверка дали е запишано она шо требало
            Assert.AreEqual(izbranRoditel.Id, izmenetRoditel.Id);
            Assert.AreEqual(izbranRoditel.Ime, izmenetRoditel.Ime);
            Assert.AreEqual(izbranRoditel.Vid, izmenetRoditel.Vid);

            Console.WriteLine("Изменетите податоци за родителот: ИД: {0}, Име: {1}, Вид: {2}", izmenetRoditel.Id, izmenetRoditel.Ime, izmenetRoditel.Vid);
        }

    }
}
