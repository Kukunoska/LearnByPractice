﻿namespace Product.Tests.DAL.Repositories
{
    using System;
    using System.Linq;

    using NUnit.Framework;

    using Product.Domain.FuncArea;
    using Product.DAL.Repositories.FuncArea;

    /// <summary>
    /// Тестови за пристап до табелата Child
    /// </summary>
    [TestFixture]
    public class ChildRepositoryTests
    {
        /// <summary>
        /// Тест за методот Get
        /// </summary>
        [Test]
        public void GetByIdTest()
        {
            ChildRepository repository = new ChildRepository();
            Child child = repository.Get(1);
            // Проверка дали податоците се совпаѓаат со оние од Database\InitialData\Child.sql
            Assert.AreEqual(1, child.Id);
            Assert.AreEqual("Дете 1.1", child.Ime);
            Assert.AreEqual(1, child.IdParent);
        }

        /// <summary>
        /// Тест за методот GetByParentId
        /// </summary>
        [Test]
        public void GetByParentIdTest()
        {
            ChildRepository repository = new ChildRepository();
            ChildCollection decaNaRoditel2 = repository.GetByParentId(2);
            // Проверка дали податоците се совпаѓаат со оние од Database\InitialData\Child.sql
            Assert.IsNotNull(decaNaRoditel2);
            Assert.IsTrue(decaNaRoditel2.Count >= 3);
            // Испитување дали за сите објекти во decaNaRoditel2, IdParent е 2
            Assert.IsTrue(decaNaRoditel2.All(dete => dete.IdParent == 2));
            foreach(Child dete in decaNaRoditel2)
            {
                Console.WriteLine("ИД: {0}, Име: {1}, Родител ИД: {2}", dete.Id, dete.Ime, dete.IdParent);
            }
        }

        /// <summary>
        /// Тест за методот Insert
        /// </summary>
        [Test]
        public void InsertTest()
        {
            // Прво определи во кој родител ќе се додава детето
            ParentRepository parentRepository = new ParentRepository();
            ParentCollection siteRoditeli = parentRepository.GetAll();

            Random random = new Random(DateTime.Now.Millisecond);
            int roditelId = random.Next(0, siteRoditeli.Count);
            Parent izbranRoditel = siteRoditeli[roditelId];

            Console.WriteLine("Додавам дете на родител ИД: {0}, Име: {1}, Вид: {2}", izbranRoditel.Id, izbranRoditel.Ime, izbranRoditel.Vid);

            Child novoDete = new Child();
            // За да се добиваат при секое извршување нови вредности се користи Guid.NewGuid()
            novoDete.Ime = string.Format("Дете {0}", Guid.NewGuid().ToString());
            novoDete.IdParent = izbranRoditel.Id;

            ChildRepository childRepository = new ChildRepository();
            Child dodadenoDete = childRepository.Insert(novoDete);

            // Испитај дали вредностите се точни
            Assert.IsNotNull(dodadenoDete);
            // Проверка дали е вратен нов генериран ИД
            Assert.AreNotEqual(0, dodadenoDete.Id);
            // Проверка дали е запишано она шо требало
            Assert.AreEqual(novoDete.Ime, dodadenoDete.Ime);
            Assert.AreEqual(novoDete.IdParent, dodadenoDete.IdParent);

            Console.WriteLine("Додадено е ново дете ИД: {0}, Име: {1}, Родител ИД: {2}", novoDete.Id, novoDete.Ime, novoDete.IdParent);
        }
    }
}
