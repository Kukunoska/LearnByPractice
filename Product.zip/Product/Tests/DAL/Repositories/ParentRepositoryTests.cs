﻿namespace Product.Tests.DAL.Repositories
{
    using System;

    using NUnit.Framework;

    using Product.Domain.FuncArea;
    using Product.DAL.Repositories.FuncArea;

    /// <summary>
    /// Тестови за пристап до табелата Parent
    /// </summary>
    [TestFixture]
    public class ParentRepositoryTests
    {
        /// <summary>
        /// Тест за методот Get
        /// </summary>
        [Test]
        public void GetByIdTest()
        {
            ParentRepository repository = new ParentRepository();
            Parent parent = repository.Get(2);
            // Проверка дали податоците се совпаѓаат со оние од Database\InitialData\Parent.sql
            Assert.AreEqual(2, parent.Id);
        }

        /// <summary>
        /// Тест за методот GetAll
        /// </summary>
        [Test]
        public void GetAllTest()
        {
            ParentRepository repository = new ParentRepository();
            ParentCollection siteParenti = repository.GetAll();
            Assert.IsNotNull(siteParenti);

            Assert.IsTrue(siteParenti.Count >= 3); // Бидејќи во Database\InitialData\Parent.sql додаваме 3 записи

            foreach(Parent edenParent in siteParenti)
            {
                Console.WriteLine("ИД: {0}, Име: {1}, Вид: {2}", edenParent.Id, edenParent.Ime, edenParent.Vid);
            }
        }

        /// <summary>
        /// Помошен метод за генерирање на псеудо-случајна вредност за Vid
        /// </summary>
        /// <returns></returns>
        protected Vid SluchaenVid()
        {
            // За да биди поинтересно, се користат псеудо-случајни броеви
            Random random = new Random(DateTime.Now.Millisecond);

            // 4-ката се исклучува од опсегот, се генерираат броеви од 1 до 3
            int randomInt = random.Next(1, 4);
            switch (randomInt)
            {
                case 1:
                    return Vid.A;

                case 2:
                    return Vid.B;

                case 3:
                    return Vid.C;

                default:
                    throw new InvalidOperationException("Добиена е случајна вредност надвор од дадените граници.");
            }
        }

        /// <summary>
        /// Тест за методот Insert
        /// </summary>
        [Test]
        public void InsertTest()
        {
            Parent novRoditel = new Parent();
            // За да се добиваат при секое извршување нови вредности се користи Guid.NewGuid()
            novRoditel.Ime = string.Format("Родител {0}", Guid.NewGuid().ToString());
            novRoditel.Vid = SluchaenVid();

            ParentRepository repository = new ParentRepository();
            Parent dodadenRoditel = repository.Insert(novRoditel);

            // Испитување на резултатот
            Assert.IsNotNull(dodadenRoditel);
            // Проверка дали е вратен нов генериран ИД
            Assert.AreNotEqual(0, dodadenRoditel.Id);
            // Проверка дали е запишано она шо требало
            Assert.AreEqual(novRoditel.Ime, dodadenRoditel.Ime);
            Assert.AreEqual(novRoditel.Vid, dodadenRoditel.Vid);

            Console.WriteLine("Додаден е нов родител: ИД: {0}, Име: {1}, Вид: {2}", dodadenRoditel.Id, dodadenRoditel.Ime, dodadenRoditel.Vid);
        }

        /// <summary>
        /// Тест за методот Insert
        /// </summary>
        [Test]
        public void UpdateTest()
        {
            ParentRepository repository = new ParentRepository();
            
            // Прво определи за кој родител ќе се менуваат податоците
            ParentCollection siteRoditeli = repository.GetAll();

            Random random = new Random(DateTime.Now.Millisecond);
            int roditelId = random.Next(0, siteRoditeli.Count);
            Parent izbranRoditel = siteRoditeli[roditelId];

            Console.WriteLine("Се менуваат податоците за родител ИД: {0}, Име: {1}, Вид: {2}", izbranRoditel.Id, izbranRoditel.Ime, izbranRoditel.Vid);

            izbranRoditel.Ime = string.Format("Изменет родител {0}", Guid.NewGuid().ToString());
            izbranRoditel.Vid = SluchaenVid();

            Parent izmenetRoditel = repository.Update(izbranRoditel);

            // Испитување на резултатот
            Assert.IsNotNull(izmenetRoditel);
            // Проверка дали е запишано она шо требало
            Assert.AreEqual(izbranRoditel.Id, izmenetRoditel.Id);
            Assert.AreEqual(izbranRoditel.Ime, izmenetRoditel.Ime);
            Assert.AreEqual(izbranRoditel.Vid, izmenetRoditel.Vid);

            Console.WriteLine("Изменетите податоци за родителот: ИД: {0}, Име: {1}, Вид: {2}", izmenetRoditel.Id, izmenetRoditel.Ime, izmenetRoditel.Vid);
        }
    }
}
