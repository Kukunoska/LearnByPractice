﻿INSERT INTO dbo.Child (ParentId, ImeChild)
SELECT
	p.IdParent, tmp.childIme
FROM
	-- Sub-query кое ќе игра улога на „привремена табела“ ...
	(
		-- Родител 1 ќе има еден запис-дете (имињата на колони се дефинираат само во првиот SELECT)
		SELECT N'Родител 1' AS imeParent, N'Дете 1.1'  AS childIme

		-- Родител 2 ќе има 3 записи-дете
		UNION ALL SELECT N'Родител 2', N'Дете 2.1'
		UNION ALL SELECT N'Родител 2', N'Дете 2.2'
		UNION ALL SELECT N'Родител 2', N'Дете 2.3'

		-- Родител 3 ќе има 5 записи-дете
		UNION ALL SELECT N'Родител 3', N'Дете 3.1'
		UNION ALL SELECT N'Родител 3', N'Дете 3.2'
		UNION ALL SELECT N'Родител 3', N'Дете 3.3'
		UNION ALL SELECT N'Родител 3', N'Дете 3.4'
		UNION ALL SELECT N'Родител 3', N'Дете 3.5'
	) AS tmp
	-- ... која треба да се поврзи со dbo.Parent за да се добијат ParentId
	INNER JOIN dbo.Parent AS p
		ON (p.ImeParent = tmp.imeParent)
;