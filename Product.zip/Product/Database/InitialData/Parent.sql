﻿INSERT INTO dbo.Parent (ImeParent, VidParent)
SELECT N'Родител 1', 'A'
UNION ALL SELECT N'Родител 2', 'B'
UNION ALL SELECT N'Родител 3', 'C'
;
