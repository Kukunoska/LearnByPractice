﻿CREATE TABLE [dbo].[Parent]
(
	[IdParent] INT IDENTITY(1, 1) NOT NULL,
    [ImeParent] NVARCHAR(100) NOT NULL,
	[VidParent] CHAR(1) NOT NULL

	CONSTRAINT PK_Parent PRIMARY KEY CLUSTERED (IdParent),
	CONSTRAINT UK_Parent_ImeParentIme UNIQUE (ImeParent),
	CONSTRAINT CK_Parent_VidParent CHECK (VidParent IN ('A', 'B', 'C'))
)