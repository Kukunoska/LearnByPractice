﻿CREATE TABLE [dbo].[Child]
(
	[IdChild] INT IDENTITY(1, 1) NOT NULL,
	[ImeChild] NVARCHAR(100) NOT NULL,
	[ParentId] INT NOT NULL,

	-- NONCLUSTERED е зато шо UNIQUE CONSTRAINT-от подолу е CLUSTERED,
	-- а една табела можи да има само еден CLUSTERED INDEX
	CONSTRAINT PK_Child PRIMARY KEY NONCLUSTERED (IdChild),
	-- Не можи да има две деца со исто име во рамки на еден родител.
	-- CLUSTERED е за да бидат децата на еден родител ФИЗИЧКИ ГРУПИРАНИ на едно место
	CONSTRAINT UK_Child_ParentId_ChildIme UNIQUE CLUSTERED (ParentId, ImeChild),
	CONSTRAINT FK_Child_Parent FOREIGN KEY (ParentId) REFERENCES dbo.Parent (IdParent)
)
